package com.example.productservice.service;

import com.example.productservice.model.Product;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ProductService {

    private final List<Product> productList = new ArrayList<>();

    public ProductService() {
        // Initialize with some sample data
        productList.add(new Product("1", "Laptop", 1200.0));
        productList.add(new Product("2", "Smartphone", 800.0));
        productList.add(new Product("3", "Tablet", 400.0));
    }

    public List<Product> getAllProducts() {
        return productList;
    }

    public Product getProductById(String id) {
        return productList.stream()
                .filter(product -> product.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public Product addProduct(Product product) {
        productList.add(product);
        return product;
    }

    public String deleteProduct(String id) {
        boolean removed = productList.removeIf(product -> product.getId().equals(id));
        if (removed) {
            return "Product with ID " + id + " has been removed.";
        } else {
            return "Product with ID " + id + " not found.";
        }
    }
}
