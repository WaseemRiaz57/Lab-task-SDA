
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

// Main Application Class
@SpringBootApplication
public class MonolithicApp {
    public static void main(String[] args) {
        SpringApplication.run(MonolithicApp.class, args);
    }
}

// User Entity
class User {
    private Long id;
    private String name;

    public User(Long id, String name) {
        this.id = id;
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

// Product Entity
class Product {
    private Long id;
    private String name;

    public Product(Long id, String name) {
        this.id = id;
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

// Order Entity
class Order {
    private Long id;
    private String userName;
    private String productName;

    public Order(Long id, String userName, String productName) {
        this.id = id;
        this.userName = userName;
        this.productName = productName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }
}

// User Controller
@RestController
@RequestMapping("/users")
class UserController {
    private List<User> users = new ArrayList<>();

    @GetMapping
    public List<User> getAllUsers() {
        return users;
    }

    @PostMapping
    public User createUser(@RequestBody User user) {
        users.add(user);
        return user;
    }
}

// Product Controller
@RestController
@RequestMapping("/products")
class ProductController {
    private List<Product> products = new ArrayList<>();

    @GetMapping
    public List<Product> getAllProducts() {
        return products;
    }

    @PostMapping
    public Product createProduct(@RequestBody Product product) {
        products.add(product);
        return product;
    }
}

// Order Controller
@RestController
@RequestMapping("/orders")
class OrderController {
    private final List<Order> orders = new ArrayList<>();

    @PostMapping
    public Order createOrder(@RequestBody Order order) {
        orders.add(order);
        return order;
    }

    @GetMapping
    public List<Order> getAllOrders() {
        return orders;
    }

    @GetMapping("/users")
    public List<User> getAllUsers() {
        return new UserController().getAllUsers();
    }

    @GetMapping("/products")
    public List<Product> getAllProducts() {
        return new ProductController().getAllProducts();
    }
}
