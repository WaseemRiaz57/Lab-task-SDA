package RefactringGURU;

public interface events {

}
