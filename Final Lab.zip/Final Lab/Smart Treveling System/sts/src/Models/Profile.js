export default class Profile {
    constructor(preferences, region, avatar, information) {
      this.preferences = preferences; // Travel preferences
      this.region = region; // Preferred travel region
      this.avatar = avatar; // Profile picture path
      this.information = information; // Additional details about the user
    }
  
    updatePreferences(newPreferences) {
      this.preferences = newPreferences;
      console.log(`Preferences updated to: ${newPreferences}`);
    }
  
    setRegion(newRegion) {
      this.region = newRegion;
      console.log(`Region updated to: ${newRegion}`);
    }
  
    uploadAvatar(avatarPath) {
      this.avatar = avatarPath;
      console.log(`Avatar updated to: ${avatarPath}`);
    }
  
    getProfileInfo() {
      return {
        preferences: this.preferences,
        region: this.region,
        avatar: this.avatar,
        information: this.information,
      };
    }
  }
  