export default class Group {
    constructor(name, description) {
      this.name = name;
      this.description = description;
      this.members = [];
    }
  
    addUser(user) {
      this.members.push(user);
    }
  
    removeUser(user) {
      this.members = this.members.filter((member) => member.userID !== user.userID);
    }
  
    viewGroupDetails() {
      return `Group: ${this.name}, Members: ${this.members.length}`;
    }
  }
  