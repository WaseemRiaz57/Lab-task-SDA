export default class User {
    constructor(userID, name, email, dateOfBirth) {
      this.userID = userID;
      this.name = name;
      this.email = email;
      this.dateOfBirth = dateOfBirth;
    }
  
    register(name, email, dob) {
      // Registration logic
      console.log(`Registered user: ${name}, Email: ${email}`);
    }
  
    login(email, password) {
      // Mock authentication
      return email === "test@example.com" && password === "password123";
    }
  }
  