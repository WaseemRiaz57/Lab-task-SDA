export default class Message {
    constructor(content, subject, sender, receiver) {
      this.content = content; // Message content
      this.subject = subject; // Message subject/title
      this.sender = sender; // Sender's identifier (e.g., userID)
      this.receiver = receiver; // Receiver's identifier (e.g., userID or groupID)
      this.timestamp = new Date(); // Automatically set timestamp when the message is created
    }
  
    createMessage(content, subject) {
      this.content = content;
      this.subject = subject;
      this.timestamp = new Date();
      console.log(`Message created: ${subject}`);
      return this;
    }
  
    send(target) {
      // Simulate sending a message
      console.log(`Message sent to ${target}`);
      return true; // Return true if the message is sent successfully
    }
  
    reply(content) {
      const replyMessage = new Message(content, `Re: ${this.subject}`, this.receiver, this.sender);
      console.log(`Reply created: ${replyMessage.subject}`);
      return replyMessage;
    }
  
    deleteMessage() {
      console.log("Message deleted");
      return null; // Simulate deletion by nullifying the message
    }
  }
  