import React from "react";
import Login from "./Components/Login";
import LoginPage from "./Components/LoginPage";
improt LoginPage

const App = () => {
  return (
    <div>
      <h1>Smart Travel System</h1>
      <Login/>
      <LoginPage/>
    </div>
  );
};

export default App;
